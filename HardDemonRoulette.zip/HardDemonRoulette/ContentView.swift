
import SwiftUI

struct Demon: Identifiable, Codable {
    let id = UUID()
    let name: String
    let levelID: Int
}

struct ContentView: View {
    @State private var demons: [Demon] = DemonDatabase.demons
    @State private var currentDemon: Demon?
    @State private var currentGoal: Int = 1
    @State private var completed = false
    @State private var showLoserAlert = false

    var body: some View {
        ZStack {
            LinearGradient(
                colors: [.black, .red],
                startPoint: .top,
                endPoint: .bottom
            )
            .ignoresSafeArea()

            VStack(spacing: 20) {
                Text("Hard Demon Roulette")
                    .font(.largeTitle)
                    .fontWeight(.heavy)
                    .foregroundColor(.white)

                Text("Current Goal: \(currentGoal)%")
                    .font(.title2)
                    .foregroundColor(.white)

                if let demon = currentDemon {
                    VStack(spacing: 10) {
                        Text(demon.name)
                            .font(.title)
                            .fontWeight(.bold)
                            .foregroundColor(.yellow)

                        Text("Level ID: \(demon.levelID)")
                            .foregroundColor(.white.opacity(0.85))
                    }
                    .padding()
                    .background(Color.white.opacity(0.1))
                    .cornerRadius(18)
                } else {
                    Text("Press Start")
                        .foregroundColor(.white)
                }

                Button(action: startRoulette) {
                    Text(currentDemon == nil ? "Start" : "Next Demon")
                        .fontWeight(.bold)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.green)
                        .foregroundColor(.white)
                        .cornerRadius(16)
                }

                Button(action: completeGoal) {
                    Text("Complete")
                        .fontWeight(.bold)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(16)
                }

                Button(action: {
                    showLoserAlert = true
                }) {
                    Text("Give Up")
                        .fontWeight(.bold)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.red)
                        .foregroundColor(.white)
                        .cornerRadius(16)
                }

                if completed {
                    Text("YOU BEAT THE HARD DEMON ROULETTE")
                        .font(.headline)
                        .foregroundColor(.green)
                        .padding(.top, 20)
                }

                Spacer()
            }
            .padding()
        }
        .alert("LOSER 💀", isPresented: $showLoserAlert) {
            Button("ok", role: .cancel) { }
        } message: {
            Text("you gave up before 100%")
        }
    }

    func startRoulette() {
        currentDemon = demons.randomElement()
    }

    func completeGoal() {
        guard currentGoal < 100 else {
            completed = true
            return
        }

        currentGoal += 1
        currentDemon = demons.randomElement()

        if currentGoal == 100 {
            completed = true
        }
    }
}

struct DemonDatabase {
    static let demons: [Demon] = [
        Demon(name: "Nine Circles", levelID: 4284013),
        Demon(name: "Jawbreaker", levelID: 11449795),
        Demon(name: "Fairydust", levelID: 18520916),
        Demon(name: "Ditched Machine", levelID: 24646096),
        Demon(name: "Dance Massacre", levelID: 1053321),
        Demon(name: "Forest Temple", levelID: 2091067),
        Demon(name: "Future Funk", levelID: 23238001),
        Demon(name: "The Caverns", levelID: 1306468),
        Demon(name: "Radioactive", levelID: 1224772),
        Demon(name: "Spacelocked", levelID: 25225548),
        Demon(name: "Lava Temple", levelID: 1122400),
        Demon(name: "Nowise", levelID: 31362064),
        Demon(name: "TOE III", levelID: 2213347),
        Demon(name: "Double Dash", levelID: 22753636),
        Demon(name: "Hexagon Force v2", levelID: 2691447),
        Demon(name: "Different Descent", levelID: 33022131),
        Demon(name: "CraZy", levelID: 27811444),
        Demon(name: "Psychosis", levelID: 16636829),
        Demon(name: "Extreme Park", levelID: 946438),
        Demon(name: "Sedulous", levelID: 39374774)
    ]
}

#Preview {
    ContentView()
}
