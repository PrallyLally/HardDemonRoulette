
import SwiftUI

@main
struct HardDemonRouletteApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
