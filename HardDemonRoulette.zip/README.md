
# Hard Demon Roulette

A simple SwiftUI iOS app inspired by Geometry Dash hard demon roulette challenges.

## Features
- Fully random hard demon picker
- Goal increases from 1% to 100%
- "Complete" button advances the roulette
- "Give Up" button insults you 💀
- Shows level name + level ID

## Build Instructions
1. Open the folder in Xcode
2. Create a new iOS App project named "HardDemonRoulette"
3. Replace the generated Swift files with the included ones
4. Build to your iPhone or archive as an IPA

Made for fun.
